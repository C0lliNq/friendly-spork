# RGX-Adduty
The Adduty for ESX frameworks is created by [C0lliNq](https://github.com/C0lliNq).

# Features
- Admin Outfits
- Godmode
- Nametags

# Support
Discord (https://discord.gg/eWDYxuFTZw)