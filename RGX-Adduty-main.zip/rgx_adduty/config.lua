Config = {}

Config.noclipSpeed = 1   --To change NoClip speed!
Config.noclipShiftSpeed = 10

Config.DistanceESP = 250

Config.GodmodeOptions = {
    {
        ['infiniteStamina'] = true,
        ['noRagdoll'] = true,
        ['godmode'] = true, 
        ['clearPedBlood'] = true,
    }
}

-- ! Admin Clothes ! --

Config.AdutyClothing = {
    ['owner'] = {
        ['male'] = {
            ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
            ['torso_1'] = 287,      ['torso_2'] = 2,
            ['decals_1'] = 0,       ['decals_2'] = 0,
            ['arms'] = 9,           ['arms_2'] = 0,
            ['pants_1'] = 114,      ['pants_2'] = 2,
            ['shoes_1'] = 78,       ['shoes_2'] = 2,
            ['helmet_1'] = -1,      ['helmet_2'] = 0,
            ['mask_1'] = 135,       ['mask_2'] = 2,
            ['chain_1'] = 0,        ['chain_2'] = 0,
            ['ears_1'] = 0,         ['ears_2'] = 0,
            ['bags_1'] = 0,         ['bags_2'] = 0,
            ['hair_1'] = 0,         ['hair_2'] = 0,
            ['bproof_1'] = 0,       ['bproof_2'] = 0
        },
        ['female'] = {
            ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
            ['torso_1'] = 287,      ['torso_2'] = 2,
            ['decals_1'] = 0,       ['decals_2'] = 0,
            ['arms'] = 9,           ['arms_2'] = 0,
            ['pants_1'] = 114,      ['pants_2'] = 2,
            ['shoes_1'] = 78,       ['shoes_2'] = 2,
            ['helmet_1'] = -1,      ['helmet_2'] = 0,
            ['mask_1'] = 135,       ['mask_2'] = 2,
            ['chain_1'] = 0,        ['chain_2'] = 0,
            ['ears_1'] = 0,         ['ears_2'] = 0,
            ['bags_1'] = 0,         ['bags_2'] = 0,
            ['hair_1'] = 0,         ['hair_2'] = 0,
            ['bproof_1'] = 0,       ['bproof_2'] = 0
        }
    },
    ['manager'] = {
            ['male'] = {
                ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
                ['torso_1'] = 287,      ['torso_2'] = 3,
                ['decals_1'] = 0,       ['decals_2'] = 0,
                ['arms'] = 9,           ['arms_2'] = 0,
                ['pants_1'] = 114,      ['pants_2'] = 3,
                ['shoes_1'] = 78,       ['shoes_2'] = 3,
                ['helmet_1'] = -1,      ['helmet_2'] = 0,
                ['mask_1'] = 135,       ['mask_2'] = 3,
                ['chain_1'] = 0,        ['chain_2'] = 0,
                ['ears_1'] = 0,         ['ears_2'] = 0,
                ['bags_1'] = 0,         ['bags_2'] = 0,
                ['hair_1'] = 0,         ['hair_2'] = 0,
                ['bproof_1'] = 0,       ['bproof_2'] = 0
            },
            ['female'] = {
                ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
                ['torso_1'] = 287,      ['torso_2'] = 3,
                ['decals_1'] = 0,       ['decals_2'] = 0,
                ['arms'] = 9,           ['arms_2'] = 0,
                ['pants_1'] = 114,      ['pants_2'] = 3,
                ['shoes_1'] = 78,       ['shoes_2'] = 3,
                ['helmet_1'] = -1,      ['helmet_2'] = 0,
                ['mask_1'] = 135,       ['mask_2'] = 3,
                ['chain_1'] = 0,        ['chain_2'] = 0,
                ['ears_1'] = 0,         ['ears_2'] = 0,
                ['bags_1'] = 0,         ['bags_2'] = 0,
                ['hair_1'] = 0,         ['hair_2'] = 0,
                ['bproof_1'] = 0,       ['bproof_2'] = 0
            } 
        },
        ['admin'] = {
            ['male'] = {
                ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
                ['torso_1'] = 287,      ['torso_2'] = 1,
                ['decals_1'] = 0,       ['decals_2'] = 0,
                ['arms'] = 9,           ['arms_2'] = 0,
                ['pants_1'] = 114,      ['pants_2'] = 1,
                ['shoes_1'] = 78,       ['shoes_2'] = 1,
                ['helmet_1'] = -1,      ['helmet_2'] = 0,
                ['mask_1'] = 135,       ['mask_2'] = 1,
                ['chain_1'] = 0,        ['chain_2'] = 0,
                ['ears_1'] = 0,         ['ears_2'] = 0,
                ['bags_1'] = 0,         ['bags_2'] = 0,
                ['hair_1'] = 0,         ['hair_2'] = 0,
                ['bproof_1'] = 0,       ['bproof_2'] = 0
            },
            ['female'] = {
                ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
                ['torso_1'] = 287,      ['torso_2'] = 1,
                ['decals_1'] = 0,       ['decals_2'] = 0,
                ['arms'] = 9,           ['arms_2'] = 0,
                ['pants_1'] = 114,      ['pants_2'] = 1,
                ['shoes_1'] = 78,       ['shoes_2'] = 1,
                ['helmet_1'] = -1,      ['helmet_2'] = 0,
                ['mask_1'] = 135,       ['mask_2'] = 1,
                ['chain_1'] = 0,        ['chain_2'] = 0,
                ['ears_1'] = 0,         ['ears_2'] = 0,
                ['bags_1'] = 0,         ['bags_2'] = 0,
                ['hair_1'] = 0,         ['hair_2'] = 0,
                ['bproof_1'] = 0,       ['bproof_2'] = 0
            }
        },
        ['mod'] = {
            ['male'] = {
                ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
                ['torso_1'] = 287,      ['torso_2'] = 0,
                ['decals_1'] = 0,       ['decals_2'] = 0,
                ['arms'] = 9,           ['arms_2'] = 0,
                ['pants_1'] = 114,      ['pants_2'] =0 ,
                ['shoes_1'] = 78,       ['shoes_2'] = 0,
                ['helmet_1'] = -1,      ['helmet_2'] = 0,
                ['mask_1'] = 135,       ['mask_2'] = 0,
                ['chain_1'] = 0,        ['chain_2'] = 0,
                ['ears_1'] = 0,         ['ears_2'] = 0,
                ['bags_1'] = 0,         ['bags_2'] = 0,
                ['hair_1'] = 0,         ['hair_2'] = 0,
                ['bproof_1'] = 0,       ['bproof_2'] = 0
            },
            ['female'] = {
                ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
                ['torso_1'] = 287,      ['torso_2'] = 0,
                ['decals_1'] = 0,       ['decals_2'] = 0,
                ['arms'] = 9,           ['arms_2'] = 0,
                ['pants_1'] = 114,      ['pants_2'] = 0,
                ['shoes_1'] = 78,       ['shoes_2'] = 0,
                ['helmet_1'] = -1,      ['helmet_2'] = 0,
                ['mask_1'] = 155,       ['mask_2'] = 0,
                ['chain_1'] = 0,        ['chain_2'] = 0,
                ['ears_1'] = 0,         ['ears_2'] = 0,
                ['bags_1'] = 0,         ['bags_2'] = 0,
                ['hair_1'] = 0,         ['hair_2'] = 0,
                ['bproof_1'] = 0,       ['bproof_2'] = 0
            }
        },
        ['supporter'] = {
            ['male'] = {
                ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
                ['torso_1'] = 287,      ['torso_2'] = 5,
                ['decals_1'] = 0,       ['decals_2'] = 0,
                ['arms'] = 9,           ['arms_2'] = 0,
                ['pants_1'] = 114,      ['pants_2'] =5 ,
                ['shoes_1'] = 78,       ['shoes_2'] = 5,
                ['helmet_1'] = -1,      ['helmet_2'] = 0,
                ['mask_1'] = 135,       ['mask_2'] = 5,
                ['chain_1'] = 0,        ['chain_2'] = 0,
                ['ears_1'] = 0,         ['ears_2'] = 0,
                ['bags_1'] = 0,         ['bags_2'] = 0,
                ['hair_1'] = 0,         ['hair_2'] = 0,
                ['bproof_1'] = 0,       ['bproof_2'] = 0
            },
            ['female'] = {
                ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
                ['torso_1'] = 287,      ['torso_2'] = 5,
                ['decals_1'] = 0,       ['decals_2'] = 0,
                ['arms'] = 9,           ['arms_2'] = 0,
                ['pants_1'] = 114,      ['pants_2'] = 5,
                ['shoes_1'] = 78,       ['shoes_2'] = 5,
                ['helmet_1'] = -1,      ['helmet_2'] = 0,
                ['mask_1'] = 135,       ['mask_2'] = 5,
                ['chain_1'] = 0,        ['chain_2'] = 0,
                ['ears_1'] = 0,         ['ears_2'] = 0,
                ['bags_1'] = 0,         ['bags_2'] = 0,
                ['hair_1'] = 0,         ['hair_2'] = 0,
                ['bproof_1'] = 0,       ['bproof_2'] = 0
            }
        },
        ['supportleitung'] = {
            ['male'] = {
                ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
                ['torso_1'] = 287,      ['torso_2'] = 7,
                ['decals_1'] = 0,       ['decals_2'] = 0,
                ['arms'] = 9,           ['arms_2'] = 0,
                ['pants_1'] = 114,      ['pants_2'] =7 ,
                ['shoes_1'] = 78,       ['shoes_2'] = 7,
                ['helmet_1'] = -1,      ['helmet_2'] = 0,
                ['mask_1'] = 135,       ['mask_2'] = 7,
                ['chain_1'] = 0,        ['chain_2'] = 0,
                ['ears_1'] = 0,         ['ears_2'] = 0,
                ['bags_1'] = 0,         ['bags_2'] = 0,
                ['hair_1'] = 0,         ['hair_2'] = 0,
                ['bproof_1'] = 0,       ['bproof_2'] = 0
            },
            ['female'] = {
                ['tshirt_1'] = 15,      ['tshirt_2'] = 0,
                ['torso_1'] = 287,      ['torso_2'] = 7,
                ['decals_1'] = 0,       ['decals_2'] = 0,
                ['arms'] = 9,           ['arms_2'] = 0,
                ['pants_1'] = 114,      ['pants_2'] = 7,
                ['shoes_1'] = 78,       ['shoes_2'] = 7,
                ['helmet_1'] = -1,      ['helmet_2'] = 0,
                ['mask_1'] = 135,       ['mask_2'] = 7,
                ['chain_1'] = 0,        ['chain_2'] = 0,
                ['ears_1'] = 0,         ['ears_2'] = 0,
                ['bags_1'] = 0,         ['bags_2'] = 0,
                ['hair_1'] = 0,         ['hair_2'] = 0,
                ['bproof_1'] = 0,       ['bproof_2'] = 0
            }
        },

    }